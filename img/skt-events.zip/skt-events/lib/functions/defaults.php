<?php
function complete_option_defaults() {
	$defaults = array(
		'converted' => '',
		'site_layout_id' => 'site_full',
		'hide_site_animation' => '',
		'single_post_layout_id' => 'single_layout1',
		'header_layout_id' => 'header_layout1',
		'center_width' => 83.50,
		'content_bg_color' => '#ffffff',
		'divider_icon' => 'fa-stop',
		'head_transparent' => '1',
		'trans_header_color' => '#fff',
		'totop_id' => '1',
		'footer_text_id' => __('
[row_area]				
	[columns size="3"]		
			<div class="left">&copy; Copyright 2019 <span style="color:#da3884;">SKT Events.</span> | All Rights Reserved</div>
	[/columns]	
	[columns size="3"]		
	[social_area]
		[social icon="facebook" link="#"]
		[social icon="twitter" link="#"]
		[social icon="google-plus" link="#"]	
		[social icon="linkedin" link="#"]
		[social icon="pinterest" link="#"]
	[/social_area]
	[/columns]	
	[columns size="3"]		
			<div class="right">Powered by SKT Themes</div>
	[/columns]	
	[clear]
[/row_area]			
		', 'complete'),
		'phntp_text_id' => __('<a href="tel:91+ 9898 55 22 23"><i class="fa fa-phone"></i> 91+ 9898 55 22 23</a> <a href="mailto:info@sitename.com"><i class="fa fa-envelope"></i> info@sitename.com</a>', 'complete'),
		'suptp_text' => '[social_area]
    [social icon="facebook" link="#"]
    [social icon="twitter" link="#"]
    [social icon="google-plus" link="#"]	
    [social icon="linkedin" link="#"]
    [social icon="pinterest" link="#"]
[/social_area]',
		'menu_bar_button' => '',
		'footmenu_id' => '1',
		'copyright_center' => '',
		
		'custom_slider' => '',
		'slider_type_id' => 'static',
		
		
		'sldtitle_font_id' => array('font-family' => 'Assistant', 'font-size' => '88px'),
		'slddesc_font_id' => array('font-family' => 'Assistant', 'font-size' => '24px'),
		'sldbtn_font_id' => array('font-family' => 'Assistant', 'font-size' => '18px'),
		
		'slidetitle_color_id' => '#ffffff',	
		'slddesc_color_id' => '#ffffff',	
		'sldbtntext_color_id' => '#ffffff',
		'sldbtn_color_id' => '#ffffff',
		'sldbtn_hvcolor_id' => '#da3884',	
		
		'slide_pager_color_id' => '#ffffff',	
		'slide_active_pager_color_id' => '#000000',	
		
		'slide_image1' => ''.get_template_directory_uri().'/images/slides/slider1.jpg',
		'slide_title1' => 'Wedding Planners',
		'slide_desc1' => 'THE BEST TIME TO CELEBRATE',
		'slide_link1' => '#link1',
		'slide_btn1' => 'READ MORE',
		
		'slide_image2' => ''.get_template_directory_uri().'/images/slides/slider2.jpg',
		'slide_title2' => 'Birthday Planners',
		'slide_desc2' => 'THE BEST TIME TO CELEBRATE',
		'slide_link2' => '#link2',
		'slide_btn2' => 'READ MORE',
		
		'slide_image3' => ''.get_template_directory_uri().'/images/slides/slider3.jpg',
		'slide_title3' => 'SKT Eventss',
		'slide_desc3' => 'THE BEST TIME TO CELEBRATE',
		'slide_link3' => '#link3',
		'slide_btn3' => 'READ MORE',
		
		'slideefect' => 'fade',
		'slideanim' => '500',
		'slidepause' => '4000',
		'slidenav' => 'false',
		'slidepage' => 'true',
		
		'n_slide_time_id' => '6000',
		'slide_height' => '500px',
		'slidefont_size_id' => '36px',
		'slider_txt_hide' => '',

		'post_info_id' => '1',
		'post_nextprev_id' => '1',
		'post_comments_id' => '1',
		'page_header_color' => '#545556',
		'pageheader_bg_image' => '',
		'hide_pageheader' => '',
		'page_header_txtcolor' => '#555555',
		
		'post_header_color' => '#545556',
		'postheader_bg_image' => '',
		'hide_postheader' => '',		

		'blog_cat_id' => '',
		'blog_num_id' => '9',
		'blog_layout_id' => '',
		'show_blog_thumb' => '1',
		
		'sec_color_id' => '#da3884',
		'mnbg_color_id' => '#da3884',
		'submnu_textcolor_id' => '#000000',
		'submnbg_color_id' => '#ffffff',
		'mnshvr_color_id' => '#f0f0f0',
		'mobbg_color_id' => '#383939',
		'mobbgtop_color_id' => '#da3884',
		'mobmenutxt_color_id' => '#FFFFFF',
		
		'mobtoggle_color_id' => '#ffffff',
		'mobtoggleinner_color_id' => '#FFFFFF',
		
		'sectxt_color_id' => '#FFFFFF',
		'content_font_id' =>  array('font-family' => 'Roboto', 'font-size' => '16px'),
		'primtxt_color_id' => '#6f6e6e',
		
		'logo_image_id' => array(  'url'=>''.get_template_directory_uri().'/images/logo.png'),
		'logo_font_id' => array('font-family' => 'Kaushan Script', 'font-size' => '35px'),
		'logo_color_id' => '#ffffff',
		
		'logo_image_height' => '70px;',
		'logo_image_width' => '130px;',
		'logo_margin_top' => '20px;',
		
		'tpbt_font_id' => array('font-family' => 'Lato', 'font-size' => '14px'),
		'tpbt_color_id' => '#ffffff',
		'tpbt_hvcolor_id' => '#da3884',	
		
		
			
		'global_link_color_id' => '#da3884',
		'global_link_hvcolor_id' => '#282828',		
		
		'global_h1_color_id' => '#282828',
		'global_h1_hvcolor_id' => '#da3884',	
		'global_h2_color_id' => '#282828',
		'global_h2_hvcolor_id' => '#da3884',
		'global_h3_color_id' => '#282828',
		'global_h3_hvcolor_id' => '#da3884',
		'global_h4_color_id' => '#393939',
		'global_h4_hvcolor_id' => '#da3884',
		'global_h5_color_id' => '#282828',
		'global_h5_hvcolor_id' => '#da3884',
		'global_h6_color_id' => '#282828',
		'global_h6_hvcolor_id' => '#da3884',	
		
		'post_meta_color_id' => '#282828',
		
		'team_box_color_id' => '#da3884',
		
		'social_text_color_id' => '#ffffff',
		'social_hover_icon_color_id' => '#da3884',
		
		'testimonialbox_color_id' => '#ffffff',		
		'testimonialbox_txt_color' => '#000000',
		'testimonial_pager_color_id' => '#282828',
		'testimonialbox_border_color' => '#e8e7e7',
		'testimonial_activepager_color_id' => '#da3884',
		'gallery_filter_color_id' => '#da3884',
		'gallery_filtertxt_color_id' => '#000000',
		'gallery_activefiltertxt_color_id' => '#ffffff',
		'skillsbar_bgcolor_id' => '#f8f8f8',
		'skillsbar_text_color_id' => '#ffffff',								
		'global_h1_font_id' => array('font-family' => 'Assistant', 'font-size' => '32px'),
		'global_h2_font_id' => array('font-family' => 'Assistant', 'font-size' => '46px'),
		'global_h3_font_id' => array('font-family' => 'Roboto', 'font-size' => '20px'),
		'global_h4_font_id' => array('font-family' => 'Roboto', 'font-size' => '18px'),
		'global_h5_font_id' => array('font-family' => 'Lato', 'font-size' => '11px'),
		'global_h6_font_id' => array('font-family' => 'Lato', 'font-size' => '9px'),
		
		'contact_title' => 'Contact Info',
		'contact_address' => 'Donec ultricies mattis nulla Australia',
		'contact_phone' => '0789 256 321',
		'contact_email' => 'info@companyname.com',
		'contact_company_url' => 'http://demo.com',
		
		'head_bg_trans' => '0.0',
		'head_color_id' => '#282828',
		'head_info_color_id' => '#000000',
		'menutxt_color_id' => '#ffffff',
		'menutxt_color_hover' => '#000000',
		'menutxt_color_active' => '#000000',
		'menu_size_id' => '15px',
		'sidebar_color_id' => '#FFFFFF',
		'sidebarborder_color_id' => '#eeeff5',
		'sidebar_tt_color_id' => '#666666',
		'sidebartxt_color_id' => '#999999',
		'sidebarlink_color_id' => '#282828',
		'sidebarlink_hover_color_id' => '#da3884',
		'flipbg_front_color_id' => '#ffffff',
		'flipbg_back_color_id' => '#f7f7f7',
		'flipborder_front_color_id' => '#e0e0e0',
		'flipborder_back_color_id' => '#000000',
		'divider_color_id' => '#8c8b8b',
		'wgttitle_size_id' => '16px',
		'timebox_color_id' => '#ffffff',
		'timeboxborder_color_id' => '#dedede',
		'gridbox_color_id' => '#ffffff',
		'gridboxborder_color_id' => '#cccccc',
		
		'service_box_bg' => '#da3884',
		'box_color_text' => '#323131',
		'box_color_text_hover' => '#da3884',
		
		'expand_bg_color' => '#da3884',
		'expand_text_color' => '#000000',
		
		'h_seprator_color' => '#da3884',
		'h_seprator_text_color' => '#000000',
		
		'shows_box_hover_bg' => '#ffffff',
		'shows_box_text_color' => '#282828',
		'shows_box_hover_text_color' => '#000000',
		'shows_buy_button_bg_color' => '#ffffff',
		'shows_buy_text_color' => '#000000',
		'shows_buy_hover_bg_color' => '#da3884',
		'shows_buy_hover_text_color' => '#ffffff',
		
		'v_carousel_text_color' => '#ffffff',
		'v_carousel_hvr_bg_color' => '#000000',
		
		'square_bg_color' => '#ffffff',
		'square_bg_hover_color' => '#79ab9f',
		'square_title_color' => '#000000',
		
		'style3_bg_color' => '#ffffff',
		'style3_hover_bg_color' => '#9f9f9f',
		'style3_border_color' => '#eaeaea',
		
		'perfect_bg_color' => '#ffffff',
		'perfect_border_color' => '#eaeaea',
		'perfect_hover_border_color' => '#da3884',
 
		'foot_layout_id' => '4',
		'footer_color_id' => '#151515',
		
		 
		'footer_title_font_id' => array('font-size' => '22px'),
		
		'footwdgtxt_color_id' => '#d1d0d0',
		'footwdglink_color_id' => '#da3884',
		
		'footer_title_color' => '#ffffff',
		'ptitle_font_id' =>  array('font-family' => 'Lato', 'subsets'=>'latin'),
		'mnutitle_font_id' =>  array('font-family' => 'Roboto', 'subsets'=>'latin'),
		'title_txt_color_id' => '#666666',
		'link_color_id' => '#3590ea',
		'link_color_hover' => '#1e73be',
		'txt_upcase_id' => '',
		'mnutxt_upcase_id' => '',
		'copyright_bg_color' => '#101010',
		'copyright_txt_color' => '#f8f8f8',
		
		//Footer Info Box
		'footer_info_bgcolor' => '#161616',
		'footer_info_iconcolor' => '#ffffff',
		'footer_info_titlecolor' => '#ffffff',
		'footer_info_desccolor' => '#757575',
		'footer_info_shrtcolor' => '#da3884',
		'footer_info_dividercolor' => '#1f1f1f',		
		
		'recentpost_block_button' => __('Read More', 'complete'),

		//Footer Column 1
		'foot_cols1_title' => __('About Event <strong>Planner</strong>', 'complete'),
		'foot_cols1_content' => '<p>Quisque ultricies, nisi vitae lacinia peltesque dolor risus feugiat ligula,  varius libero ligula sit amet tellus. Etiam auctor fringilla metus. Cras porta lobortis telluamet luctus. Mauris mauris sapien, facilisis nec eleifend aliquam eget augue. Praesent a ia Aenean imperdiet erat vitae lacus feugiat suscipit. Proin libero nibh finibus commodo. </p>',
		//Footer Column 1	
		
		//Footer Column 2
		'foot_cols2_title' => __('Quick <strong>Links</strong>', 'complete'),
		'foot_cols2_content' => '[footermenu menu="quicklinks"]',
		//Footer Column 2	
		
		//Footer Column 3
		'foot_cols3_title' => __('Recent <strong>News</strong>', 'complete'),
		'foot_cols3_content' => '[footerposts show="2" catid=""]',
		//Footer Column 3
		
		//Footer Column 4
		'foot_cols4_title' => __('Contact <strong>Info</strong>', 'complete'),
		'foot_cols4_content' => '<p>Street 238,52 tempor <br>Donec ultricies mattis nulla, suscipit <br>risus tristique ut.</p>
		<p><span>Phone:</span> 1.800.555.6789</p>
		<p><span>Email:</span> <a href="mailto:support@sitename.com" class="customize-unpreviewable">support@sitename.com</a></p> 
		<p><span>Web:</span> <a href="https://www.sktthemes.net">https://www.sktthemes.net</a></p>
		',
		//Footer Column 4																
		'social_button_style' => 'simple',
		'social_show_color' => '',
		'social_bookmark_pos' => 'footer',
		'social_bookmark_size' => 'normal',
		'social_single_id' => '1',
		'social_page_id' => '',
		
		//Footer Info Box 1
		'foot_infobox1_heading' => __('VISIT US', 'complete'),
		'foot_infobox1_icon' => '<i class="fa fa-map-o" aria-hidden="true"></i>',
		'foot_infobox1_description' => 'Aliquam porta tincidunt enim.',
		
		//Footer Info Box 2
		'foot_infobox2_heading' => __('EMAIL US', 'complete'),
		'foot_infobox2_icon' => '<i class="fa fa-envelope-o" aria-hidden="true"></i>',
		'foot_infobox2_description' => 'info@sitename.com',
		
		//Footer Info Box 3
		'foot_infobox3_heading' => __('CALL US', 'complete'),
		'foot_infobox3_icon' => '<i class="fa fa-phone" aria-hidden="true"></i>',
		'foot_infobox3_description' => '987 685 4528',
		
		'hide_foot_infobox' => '1',
		
		'post_lightbox_id' => '1',
		'post_gallery_id' => '1',
		'cat_layout_id' => '4',
		'hide_mob_slide' => '',
		'hide_mob_rightsdbr' => '',
		'hide_mob_page_header' => '1',
		'custom-css' => '',
	);
	
      $options = get_option('complete',$defaults);

      //Parse defaults again - see comments
      $options = wp_parse_args( $options, $defaults );

	return $options;
}?>