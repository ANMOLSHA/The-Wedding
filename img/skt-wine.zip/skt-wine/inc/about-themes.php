<?php
/**
 * SKT Wine About Theme
 *
 * @package SKT Wine
 */
 
//about theme info
add_action( 'admin_menu', 'skt_wine_abouttheme' );
function skt_wine_abouttheme() {    	
	add_theme_page( __('About Theme', 'skt-wine'), __('About Theme', 'skt-wine'), 'edit_theme_options', 'skt_wine_guide', 'skt_wine_mostrar_guide');   
} 

//guidline for about theme
function skt_wine_mostrar_guide() { 
	//custom function about theme customizer
	$return = add_query_arg( array()) ;
?>

<style type="text/css">
@media screen and (min-width: 800px) {
.col-left {float:left; width: 65%; padding: 1%;}
.col-right {float:right; width: 30%; padding:1%; border-left:1px solid #DDDDDD; }
}
</style>

<div class="wrapper-info">
	<div class="col-left">
   		   <div style="font-size:16px; font-weight:bold; padding-bottom:5px; border-bottom:1px solid #ccc;">
			  <?php esc_attr_e('About Theme Info', 'skt-wine'); ?>
		   </div>
          <p><?php esc_attr_e('SKT Wine is a wine and brewery WordPress theme which is best suited for wine shops, artists, minimal design websites, beer, bars, restaurants, recipes, chefs, cafe, coffee, food etc. Translation ready and is compatible with several SEO, multilingual and contact form apart from portfolio plugins. Simple, white based, elegant and fast theme.','skt-wine'); ?></p>
		  <a href="<?php echo SKT_PRO_THEME_URL; ?>"><img src="<?php echo esc_url(get_template_directory_uri()); ?>/images/free-vs-pro.png" alt="" /></a>
	</div><!-- .col-left -->
	
	<div class="col-right">			
			<div style="text-align:center; font-weight:bold;">
				<hr />
				<a href="<?php echo SKT_LIVE_DEMO; ?>" target="_blank"><?php esc_attr_e('Live Demo', 'skt-wine'); ?></a> | 
				<a href="<?php echo SKT_PRO_THEME_URL; ?>"><?php esc_attr_e('Buy Pro', 'skt-wine'); ?></a> | 
				<a href="<?php echo SKT_THEME_DOC; ?>" target="_blank"><?php esc_attr_e('Documentation', 'skt-wine'); ?></a>
                <div style="height:5px"></div>
				<hr />                
                <a href="<?php echo SKT_THEMES; ?>" target="_blank"><img src="<?php echo esc_url(get_template_directory_uri()); ?>/images/sktskill.jpg" alt="" /></a>
			</div>		
	</div><!-- .col-right -->
</div><!-- .wrapper-info -->
<?php } ?>