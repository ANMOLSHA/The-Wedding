<?php
/**
 * The Header for our theme.
 *
 * Displays all of the <head> section and everything up till <div class="container">
 *
 * @package SKT Wine
 */
?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="profile" href="http://gmpg.org/xfn/11">
<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>">
<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
  <div class="headertop">
     <div class="container">
      
         <?php if ( ! dynamic_sidebar( 'header-info' ) ) : ?>
                 <div class="headerinfo">
                   <?php if ( get_theme_mod('contact_no') !== "") { ?>
                    <span class="phoneno"><?php echo wp_kses_post(get_theme_mod('contact_no',__('+123 456 7890','skt-wine'))); ?></span>
                  <?php } ?>
                  
                 <?php if ( '' !== get_theme_mod( 'contact_add' ) ){ ?>
                    <span class="address"><?php echo esc_attr_e( get_theme_mod( 'contact_add', __('591 Christie Way Passaic Street, North Carolina, America ( USA )','skt-wine'))); ?></span>
                  <?php } ?>                 
                 </div>                 
           
     
            <div class="social-icons">
				<?php if ( get_theme_mod('fb_link') !== "") { ?>
                <a title="facebook" class="fb" target="_blank" href="<?php echo esc_url(get_theme_mod('fb_link','#facebook')); ?>"></a> 
                <?php } ?>
                
                <?php if ( get_theme_mod('twitt_link') !== "") { ?>
                <a title="twitter" class="tw" target="_blank" href="<?php echo esc_url(get_theme_mod('twitt_link','#twitter')); ?>"></a>
                <?php } ?> 
                
                <?php if ( get_theme_mod('gplus_link') !== "") { ?>
                <a title="google-plus" class="gp" target="_blank" href="<?php echo esc_url(get_theme_mod('gplus_link','#gplus')); ?>"></a>
                <?php } ?>
                
                <?php if ( get_theme_mod('linked_link') !== "") { ?> 
                <a title="linkedin" class="in" target="_blank" href="<?php echo esc_url(get_theme_mod('linked_link','#linkedin')); ?>"></a>
                <?php } ?>
          </div> 
     <?php endif; // end sidebar widget area ?>       
     <div class="clear"></div>
     </div><!-- .container -->
  </div><!-- .headertop -->
  <div class="header">
        <div class="container">
            <div class="logo">
            			<?php skt_wine_the_custom_logo(); ?>
                        <a href="<?php echo esc_url( home_url('/') ); ?>"><h1><?php bloginfo('name'); ?></h1>
                        <p><?php bloginfo('description'); ?></p></a>
            </div><!-- logo -->
            <div class="header_right"> 
                        
             <div class="toggle">
                <a class="toggleMenu" href="#"><?php _e('Menu','skt-wine'); ?></a>
             </div><!-- toggle --> 
             <div class="sitenav">
                    <?php wp_nav_menu(array('theme_location' => 'primary')); ?>
             </div><!-- site-nav -->
            <div class="clear"></div>
          </div><!-- header_right -->
          <div class="clear"></div>
        </div><!-- container -->
  </div><!--.header -->

<?php if ( is_front_page() || is_home() ) { ?>
<?php if( get_theme_mod( 'hide_slides' ) == '') { ?>
<!-- Slider Section -->
<?php for($sld=7; $sld<10; $sld++) { ?>
	<?php if( get_theme_mod('page-setting'.$sld)) { ?>
     <?php $slidequery = new WP_query('page_id='.get_theme_mod('page-setting'.$sld,true)); ?>
		<?php while( $slidequery->have_posts() ) : $slidequery->the_post();
        $image = wp_get_attachment_url( get_post_thumbnail_id($post->ID));
        $img_arr[] = $image;
        $id_arr[] = $post->ID;
        endwhile;
  	  }
    }
?>
<?php if(!empty($id_arr)){ ?>
<section id="home_slider">
  <div class="slider-wrapper theme-default">
    <div id="slider" class="nivoSlider">
      <?php 
	$i=1;
	foreach($img_arr as $url){ ?>
     <a href="<?php the_permalink(); ?>"><img src="<?php echo $url; ?>" title="#slidecaption<?php echo $i; ?>" /></a>
      <?php $i++; }  ?>
    </div>
		<?php 
        $i=1;
        foreach($id_arr as $id){ 
        $title = get_the_title( $id ); 
        $post = get_post($id); 
        $content = apply_filters('the_content', substr(strip_tags($post->post_content), 0, 100)); 
        ?>
    <div id="slidecaption<?php echo $i; ?>" class="nivo-html-caption">
      <div class="slide_info">
        <h2><?php echo $title; ?></h2>
        <?php echo $content; ?>
        <a class="slideMore" href="<?php echo esc_url( get_permalink() ); ?>"><?php esc_attr_e('Learn More','skt-wine'); ?></a>       
           
        <div class="clear"></div>       
      </div>
    </div>
    <?php $i++; } ?>
  </div>
  <div class="clear"></div>
  
</section>
<?php } else { ?>
<section id="home_slider">
  <div class="slider-wrapper theme-default">
    <div id="slider" class="nivoSlider"><img src="<?php echo esc_url(get_template_directory_uri()); ?>/images/slides/slider1.jpg" alt="" title="#slidecaption1" /> <img src="<?php echo esc_url(get_template_directory_uri()); ?>/images/slides/slider2.jpg" alt="" title="#slidecaption2" /> <img src="<?php echo esc_url(get_template_directory_uri()); ?>/images/slides/slider3.jpg" alt="" title="#slidecaption3" /></div>
    <div id="slidecaption1" class="nivo-html-caption">
      <div class="slide_info">
        <h2>
          <?php esc_html_e('Great Wines since 1905', 'skt-wine');?>
        </h2>
        <p><?php esc_html_e('Pellentesque habitant morbi tristique senect netus ettings malesuada fames ac turpis.', 'skt-wine');?></p>
        <a class="slideMore" href="#"><?php esc_attr_e('Learn More','skt-wine'); ?></a>       
      </div>
    </div>
    <div id="slidecaption2" class="nivo-html-caption">
      <div class="slide_info">
        <h2>
          <?php esc_html_e('Great Wines since 1905', 'skt-wine');?>
        </h2>
        <p><?php esc_html_e('Pellentesque habitant morbi tristique senect netus ettings malesuada fames ac turpis.', 'skt-wine');?></p> 
       <a class="slideMore" href="#"><?php esc_attr_e('Learn More','skt-wine'); ?></a>       
      </div>
    </div>
    <div id="slidecaption3" class="nivo-html-caption">
      <div class="slide_info">
        <h2>
          <?php esc_html_e('Great Wines since 1905', 'skt-wine');?>
        </h2>
        <p><?php esc_html_e('Pellentesque habitant morbi tristique senect netus ettings malesuada fames ac turpis.', 'skt-wine');?></p> 
        <a class="slideMore" href="#"><?php esc_attr_e('Learn More','skt-wine'); ?></a>       
      </div>
    </div>
  </div>
  <div class="clear"></div>    
</section><!-- Slider Section -->
<?php } } } ?>
      
      
<?php if (is_front_page() || is_home()) { ?> 
<?php if( get_theme_mod( 'hide_pagefourboxes' ) == '') { ?>         
<div id="pagearea">
	<div class="container">
         <?php if( get_theme_mod('speciality',false) ) { ?>
        		<?php $queryvar = new wp_query('page_id='.get_theme_mod('speciality',true));				
						while( $queryvar->have_posts() ) : $queryvar->the_post(); ?>
                        <div class="leftwrap"> 							
                            <h2><?php the_title(); ?></h2>                           
                           <p><?php echo skt_wine_content(40); ?></p>
                            <a class="ReadMore" href="<?php the_permalink(); ?>"><?php _e('Details','skt-wine'); ?></a>
                         </div>
						<?php endwhile;
						wp_reset_query(); ?>
               <?php } else { ?>
               <div class="leftwrap">               
                 <h2><?php _e('Case <span>Specials</span>','skt-wine'); ?></h2>               
                 <p><?php _e('Maecenas rutrum lacusq tincidunt nulla efficitur in. Cras dictum sem est, quis cursus lorem monterdum et malesuada fames aante ipsum primis in faucibus. Fu ullamcorper urna. Duis porta essed consequat egestas.','skt-wine'); ?></p>
                 <a class="ReadMore" href="#"><?php _e('Details','skt-wine'); ?></a>
                 </div>              
             <?php } ?>
             
           <div class="rightwrap">             
            <?php for($fx=1; $fx<4; $fx++) { ?>
        	<?php if( get_theme_mod('page-column'.$fx,false) ) { ?>
        	<?php $queryvar = new wp_query('page_id='.get_theme_mod('page-column'.$fx,true));				
			while( $queryvar->have_posts() ) : $queryvar->the_post(); ?> 
        	    <div class="threebox <?php if($fx % 3 == 0) { echo "last_column"; } ?>">
				 	 
                  <div class="page-thumbbx">
				  <?php if ( has_post_thumbnail() ) { ?>
                        <?php the_post_thumbnail();?>                        
                   <?php } else { ?>
                       <img src="<?php echo esc_url( get_template_directory_uri() ) ; ?>/images/img_404.png" width="65" alt=""/>
                   <?php } ?>
                  </div>
                 <div class="threebox-content">
                  <h3><?php the_title(); ?></h3>                 
                  <p><?php echo skt_wine_content(20); ?></p>       
                  <a class="ReadMore" href="<?php the_permalink(); ?>"><?php esc_html_e('Read More', 'skt-wine');?></a>		
                  </div>
                 
        	   </div>
             <?php endwhile;
						wp_reset_query(); ?>
        <?php } else { ?>
        <div class="threebox <?php if($fx % 3 == 0) { echo "last_column"; } ?>">
          
             <div class="page-thumbbx">
                <img src="<?php echo esc_url( get_template_directory_uri() ) ; ?>/images/services-icon<?php echo $fx; ?>.jpg" alt="" />
             </div>      
             <div class="threebox-content">
              <h3><?php esc_html_e('Pellentesque habitant morbi', 'skt-wine');?><?php echo $fx; ?></h3>
               <?php esc_html_e('Pellentesque habitant morbi tristique senect netus ettings malesuada fames ac turpis.', 'skt-wine');?>
                <a class="ReadMore" href="#"><?php esc_html_e('Read More', 'skt-wine');?></a>		
             </div>
            
         </div>
		<?php }} ?>
             
             
             </div>
        <div class="clear"></div>
    </div><!-- .container -->
 </div><!-- #pagearea -->
<div class="clear"></div>
<?php } ?>

<?php if( get_theme_mod( 'hide_welcomesection' ) == '') { ?>      
<section id="wrapfirst">
            	<div class="container">
                    <div class="welcomewrap">
					<?php if( get_theme_mod('page-setting1')) { ?>
                    <?php $queryvar = new WP_query('page_id='.get_theme_mod('page-setting1' ,true)); ?>
                     <?php while( $queryvar->have_posts() ) : $queryvar->the_post();?>                    
                       <h1><?php the_title(); ?></h1>
                       <?php the_post_thumbnail( array(570,380, true));?>      
                       <?php the_content(); ?>                     
                     <div class="clear"></div>
                    <?php endwhile; } else { ?>                    
                   <h2><?php _e('Welcome to Wine Shop','skt-wine'); ?></h2>
                   <img src="<?php echo esc_url( get_template_directory_uri() ) ; ?>/images/welcome-img.png" alt="" />
                    <p><?php _e('Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer sodales suscipit tellus, ut tristique neque suscipit a. Mauris tristique lacus quis leo imperdiet sed pulvinar dui fermentum. Aenean sit amet diam non tortor sagittis varius. Aenean at lorem nulla, sit amet interdum nibh. Mauris sit amet dictum turpis. Sed ut sapien magna. Lorem ipsum dolor sit amet, consectetur adipiscing elit  Nulla volutpat, urna eu congue venenatis, tellus odio hendrerit nibh. <br /> <br />

Aliquam gravida odio nec dui ornare tempus elementum lectus rhoncus. Suspendisse lobortis pellentesque orci, in sodales nisi pretium sit amet. Aenean vulputate, odio non euismod eleifend, magna nisl elementum lorem, ac venenatis nunc erat et metus. Nulla volutpat, urna eu congue venenatis, tellus odio hendrerit nibh, in commodo velit leo a ligula. Vestibulum ante ipsum primis.<br /> <br />

 Aliquam gravida odio nec dui ornare tempus elementum lectus rhoncus. Suspendisse lobortis pellentesque orci, in sodales nisi pretium sit amet. Aenean vulputate, odio non euismod eleifend, magna nisl elementum lorem, ac venenatis nunc erat et metus. Nulla volutpat, urna eu congue venenatis, tellus odio hendrerit nibh, in commodo velit leo a ligula. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae aenean sit amet diam non tortor sagittis varius. Aenean at lorem nulla, sit amet interdum nibh. Mauris sit amet dictum turp ','skt-wine'); ?></p>                   
                    <?php } ?>
                      
               </div><!-- welcomewrap-->
              <div class="clear"></div>
            </div><!-- container -->
 </section><div class="clear"></div>   
       
<?php }}?>