/*-----------------------------------------------------------------------------------*/
/* SKT Wine Responsive WordPress Theme */
/*-----------------------------------------------------------------------------------*/

Theme Name      :   SKT Wine
Theme URI       :   https://www.sktthemes.org/shop/free-wine-brewery-wordpress-theme/
Version         :   1.1
Tested up to    :   WP 5.2
Author          :   SKT Themes
Author URI      :   https://www.sktthemes.org/

license         :   GNU General Public License v3.0
License URI     :   http://www.gnu.org/licenses/gpl.html

/*-----------------------------------------------------------------------------------*/
/* About Author - Contact Details */
/*-----------------------------------------------------------------------------------*/

email       :   support@sktthemes.com

/*-----------------------------------------------------------------------------------*/
/* Theme Resources */
/*-----------------------------------------------------------------------------------*/

Theme is Built using the following resource bundles.

1 - All js that have been used are within folder /js of theme.
- jquery.nivo.slider.js is licensed under MIT.


2 - Roboto Condensed - https://www.google.com/fonts/specimen/Roboto+Condensed
	License: Distributed under the terms of the Apache License, version 2.0 	http://www.apache.org/licenses/

3 - 	Images used from Pixabay.
	Pixabay provides images under CC0 license 		(https://creativecommons.org/about/cc0)

	Slides:
	https://pixabay.com/en/grapes-bunch-fruit-person-holding-690230/
	https://pixabay.com/en/sparkling-wine-bubbles-glasses-two-1030754/
	https://pixabay.com/en/champagne-wine-glasses-grapes-996367/	
	

	Other Images:
	https://pixabay.com/en/wine-white-wine-sparkling-champagne-360295/	
	https://pixabay.com/en/wine-white-wine-alcohol-france-360288/
	https://pixabay.com/en/wine-red-wine-alcohol-france-drink-360291/
	

For any help you can mail us at support[at]sktthemes.com