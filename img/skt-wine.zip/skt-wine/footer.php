<?php
/**
 * The template for displaying the footer.
 *
 * Contains the closing of the #content div and all content after
 *
 * @package SKT Wine
 */
?>
<div id="footer-wrapper">
        <div class="footer">
    	<div class="container">
             <div class="cols-4 widget-column-1">  
                    <?php if ( '' !== get_theme_mod( 'contact_title' ) ){  ?>
                  	 <h5><?php echo esc_html(get_theme_mod('contact_title',__('Contact Info','skt-wine'))); ?></h5>
                  <?php } ?>
                   <?php if ( '' !== get_theme_mod( 'contact_add' ) ){ ?>                  
                   <p><?php echo esc_attr_e( get_theme_mod( 'contact_add', __('591 Christie Way Passaic Street, North Carolina, America ( USA )','skt-wine'))); ?></p>
                   <?php } ?>
               <div class="phone-no">
               <?php if ( '' !== get_theme_mod( 'contact_no' ) ){  ?>  
             		  <strong><?php _e('Phone:', 'skt-wine');?></strong> <?php echo wp_kses_post(get_theme_mod('contact_no',__('+123 456 7890','skt-wine'))); ?> <br  />
               <?php } ?>
               
             <?php if ( '' !== get_theme_mod( 'contact_mail' ) ){  ?>  
          		 <strong><?php _e('Email:', 'skt-wine');?></strong> <a href="mailto:<?php echo esc_attr(get_theme_mod('contact_mail','contact@company.com')); ?>"><?php echo esc_attr(get_theme_mod('contact_mail','contact@company.com')); ?></a>
            <?php } ?>
           </div>         
       </div><!--end .widget-column-1-->                  
			         
             
             <div class="cols-4 widget-column-2"> 
               <?php if ( '' !== get_theme_mod( 'menu_title' ) ){  ?>
               <h5><?php echo esc_html(get_theme_mod('menu_title',__('Main Menu','skt-wine'))); ?></h5>
               <?php } ?>
                <div class="menu">
                  <?php wp_nav_menu(array('theme_location' => 'footer')); ?>
                </div>                        	
                       	
              </div><!--end .widget-column-2-->     
                      
               <div class="cols-4 widget-column-3">
                <?php if ( '' !== get_theme_mod( 'about_title' ) ){  ?>
                   <h5><?php echo esc_html(get_theme_mod('about_title',__('Our Philosophy','skt-wine'))); ?></h5> 
                   <?php } ?> 
                   <?php if ( '' !== get_theme_mod( 'about_description' ) ){  ?>          	
				<p><?php echo wp_kses_post(get_theme_mod('about_description',__('Donec ut ex ac nulla pellentesque mollis in a enim. Praesent placerat sapien mauris, vitae sodales tellus venenatis ac. Suspendisse suscipit velit id ultricies auctor. Duis turpis arcu, aliquet sed sollicitudin sed, porta quis aliquet sed urna.','skt-wine'))); ?></p> 
                <?php } ?>
                
                <?php if ( get_theme_mod('footermore_link') != "") { ?> 
                    <a class="ReadMore" href="<?php echo esc_url(get_theme_mod('footermore_link','#')); ?>"><?php _e('Read More','skt-wine'); ?></a>
                    <?php } else { ?>
                   <a class="ReadMore" href="<?php echo esc_url('#'); ?>"><?php _e('Read More','skt-wine'); ?></a>
                   <?php } ?>
                    
                </div><!--end .widget-column-3-->
                
                <div class="cols-4 widget-column-4">
                 <?php if ( '' !== get_theme_mod( 'latest_title' ) ){  ?>
                <h5><?php echo esc_html(get_theme_mod('latest_title',__('Latest Post','skt-wine'))); ?></h5> 
                <?php } ?> 
                 <?php $args = array( 'posts_per_page' => 2, 'post__not_in' => get_option('sticky_posts'), 'orderby' => 'date', 'order' => 'desc' );
                    query_posts( $args ); ?>
                  <?php while ( have_posts() ) :  the_post(); ?>
                  	<div class="recent-post">
                    
                    <a href="<?php the_permalink(); ?>">
                    <?php if ( has_post_thumbnail() ) { $src = wp_get_attachment_image_src( get_post_thumbnail_id($post->ID), 'thumbnail' );   $thumbnailSrc = $src[0]; ?>
                        <img src="<?php echo $thumbnailSrc; ?>" alt="" width="60" height="auto" ><?php } 
                    else { ?>
                        <img src="<?php echo esc_url( get_template_directory_uri()); ?>/images/img_404.png" width="60"  />
                    <?php } ?></a>
					 <p><?php echo skt_wine_content(12); ?></p>
                    <a href="<?php the_permalink(); ?>"><span> <?php _e('Read more','skt-wine'); ?></span></a>
                    
                    </div>
                    <?php endwhile; ?>
                    <?php wp_reset_query(); ?>
                   
                </div><!--end .widget-column-4-->
            <div class="clear"></div>
        </div><!--end .container-->
        </div><!--end .footer-->
        <div class="copyright-wrapper">
        	<div class="container">
                <div class="copyright-txt"><?php esc_attr_e('&copy; 2016','skt-wine');?> <?php bloginfo('name'); ?>. <?php esc_attr_e('All Rights Reserved', 'skt-wine');?></div>
                <div class="design-by"><?php echo esc_html('SKT Wine');?></div>
            </div>
            <div class="clear"></div>
        </div>
    </div>
<?php wp_footer(); ?>

</body>
</html>