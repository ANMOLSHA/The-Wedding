<?php
 /**
 * The ADMIN functions for SKT Woman
 *
 * Stores all the admin functions of the template.
 *
 * @package SKT Woman
 * 
 * @since SKT Woman f1.0
 */
 


/**************** LOAD RAW CSS & JS ON BACKEND ****************/
add_action('admin_head', 'complete_editor_fix');

function complete_editor_fix() {}